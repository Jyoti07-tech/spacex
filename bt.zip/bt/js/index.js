$(document).ready(function(){
    const template = ({ mission_name, links, mission_id, launch_year, launch_success, launch_landing}) => {
    let missionId = mission_id.join(',');  
    let imagePath = links.mission_patch;  
    return `
    <div class="col-lg-3 col-sm-12 mt-3">
        <div class="card">
            <div class="card-body">
                <img class="mission-img" src=${imagePath}>
                <h5 class="blue">${mission_name}</h5>
                <span><b>Mission Ids:</b>${missionId}</span><br/>
                <span><b>Launch Year:</b>${launch_year}</span><br/>
                <span><b>Successful Launch:</b>${launch_success}</span><br/>
                <span><b>Successful Landing:</b>${launch_landing}</span>
            </div>
        </div>
    </div>
        `;
    }
    let filter = {};
    const render = (filter) => {
        let url = "https://api.spacexdata.com/v3/launches?limit=100";
        if(filter) {
            let queryString = $.param(filter);
            url += '&'+queryString; 
        }

        $.ajax({
            url: url, 
            success: function(result) {
                console.log(result);
                $('.js-space-programs-list').html(result.map(template).join(''));
            },
            error: function(err) {
                console.log(err);
            }
        });
    }

    $('.js-filter').on('click','.js-filter-item', function(e){
        let targetParent = $(e.currentTarget).parents('.js-filter')[0];
        let target = $(e.target);
        
        $(targetParent).find('.js-filter-item').removeClass('btn-primary').addClass('btn-secondary');
        target.removeClass('btn-secondary').addClass('btn-primary');
        
        let filterName = $(targetParent).data('key');
        let filterValue = target.data('value');
        
        filter[filterName] = filterValue;
        render(filter);
    });

    render();
    
});